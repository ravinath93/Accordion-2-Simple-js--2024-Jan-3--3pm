const accordition = document.getElementsByClassName('contemtBx');

for (i=0; i<accordition.length; i++){
  accordition[i].addEventListener("click", function(){
    this.classList.toggle('active')
  })
}